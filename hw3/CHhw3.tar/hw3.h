/*
 * hw2.h
 *
 *  Created on: Jan 29, 2019
 *      Author: chuntting0
 */

#ifndef HW2_H_
#define HW2_H_

#include "char_string.h"

void testCharConstructor();
void testAssignment();
void testIndexer();
void testIndexOf();
void testEquivalence();
void testAdding();
char_string copyConstructorTest(char_string l);
void testReverse();

#endif /* HW2_H_ */

#include "avl_tree_tester.h"

int main()
{
	avl_tree_tester tester;
	tester.test_adding();
}

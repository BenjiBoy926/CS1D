#include "binary_tree_tester.h"

int main()
{
	binary_tree_tester tester;
	tester.test_all();
}
